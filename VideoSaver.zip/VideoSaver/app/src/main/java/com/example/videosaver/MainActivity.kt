package com.example.videosaver

import android.Manifest
import android.app.Activity
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.webkit.URLUtil
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/**
 * Simple downloader: direct video file links (.mp4, .webm ...) ko
 * phone ke Downloads/VideoSaver folder mein save karta hai.
 * Ye kisi platform ki restriction ya watermark nahi hatata.
 */
class MainActivity : Activity() {

    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var downloadManager: DownloadManager

    private val handler = Handler(Looper.getMainLooper())
    private var currentDownloadId: Long = -1L
    private var pendingUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        urlInput = findViewById(R.id.urlInput)
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.pasteButton).setOnClickListener { pasteFromClipboard() }
        findViewById<Button>(R.id.downloadButton).setOnClickListener {
            startDownload(urlInput.text.toString().trim())
        }

        // Doosri app se share kiya hua link
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { urlInput.setText(it.trim()) }
        }
    }

    private fun pasteFromClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard khali hai", Toast.LENGTH_SHORT).show()
        } else {
            urlInput.setText(text.trim())
        }
    }

    private fun startDownload(url: String) {
        if (!URLUtil.isNetworkUrl(url)) {
            statusText.text = "Sahi link daalein (http:// ya https:// se shuru hona chahiye)."
            return
        }

        // Android 9 aur us se purane phones par storage permission chahiye
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingUrl = url
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
            return
        }

        val fileName = URLUtil.guessFileName(url, null, "video/mp4")
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle(fileName)
            .setDescription("Video Saver")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS, "VideoSaver/$fileName"
            )

        currentDownloadId = downloadManager.enqueue(request)
        statusText.text = "Download shuru ho gaya: $fileName"
        progressBar.progress = 0
        progressBar.visibility = android.view.View.VISIBLE
        handler.post(progressChecker)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            pendingUrl?.let { startDownload(it) }
        } else {
            statusText.text = "Download ke liye storage permission zaroori hai."
        }
    }

    private val progressChecker = object : Runnable {
        override fun run() {
            val cursor = downloadManager.query(DownloadManager.Query().setFilterById(currentDownloadId))
            cursor.use {
                if (!it.moveToFirst()) return
                val status = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val downloaded = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = it.getLong(it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))

                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> {
                        progressBar.progress = 100
                        statusText.text = "Mukammal! Video Downloads/VideoSaver folder mein save ho gayi."
                        return
                    }
                    DownloadManager.STATUS_FAILED -> {
                        progressBar.visibility = android.view.View.GONE
                        statusText.text = "Download fail ho gaya. Link direct video file ka hona chahiye " +
                            "aur server download allow karta ho."
                        return
                    }
                    else -> {
                        if (total > 0) {
                            progressBar.progress = ((downloaded * 100) / total).toInt()
                            statusText.text = "Download ho raha hai... ${progressBar.progress}%"
                        }
                    }
                }
            }
            handler.postDelayed(this, 700)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressChecker)
        super.onDestroy()
    }
}
