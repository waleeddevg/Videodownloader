# Video Saver

Direct video links (.mp4, .webm) ko phone mein download karne wali simple Android app.
Ye TikTok/YouTube jaise platforms se extract nahi karti aur kisi watermark ya restriction ko nahi hatati.

## APK banane ke 2 tareeqe

### 1. GitHub se (computer ki zaroorat nahi, phone se ho sakta hai)
1. github.com par free account banayein, naya repository banayein.
2. Is poore folder ki files upload karein (`.github` folder samet).
3. Repository mein **Actions** tab kholen, "Build APK" run hone dein (5-8 minute).
4. Run mukammal hone par neeche **Artifacts** mein `VideoSaver-apk` download karein, zip khol kar `app-debug.apk` install karein.

### 2. Android Studio se
1. Android Studio mein **Open** se is folder ko kholen.
2. Sync hone ke baad **Build > Build APK(s)** chalayein.
3. APK `app/build/outputs/apk/debug/app-debug.apk` mein milegi.

Install karte waqt phone mein "Install unknown apps" allow karna padega.
